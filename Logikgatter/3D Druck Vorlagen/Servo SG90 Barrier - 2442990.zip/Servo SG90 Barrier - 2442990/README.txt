Servo SG90 Barrier by Vlastimil3 on Thingiverse: https://www.thingiverse.com/thing:2442990

Summary:
3D printed barrier that fits SG90 servo.Also there are 3 files that can make up barrier arm with vertical bars. All is connected together using M2 screws.