fischertechnik SG90 mini servo mount by NBGer on Thingiverse: https://www.thingiverse.com/thing:4663883

Summary:
Fischertechnik compatible mount for SG90 mini servoAdvantages:space saving ( 30x15x30 mm), according to fischertechnik standard block dimensionssingle print part. The servo ist just clipped in.