Fischertechnik Mount for HC-SR04 (Ultrasonic Sensor) by NBGer on Thingiverse: https://www.thingiverse.com/thing:4790589

Summary:
Fischertechnik compatible mount for HC-SR04 ultrasonic sensor.Sensor mount without screws. Just snap in the sensor.Dimensions (LxBxH): 45x15x22.5 mm